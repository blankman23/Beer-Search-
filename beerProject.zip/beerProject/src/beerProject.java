/**
 * Shawn Blank
 * 2/4/20
 * project #1
 * This project will take the given text file
 * and search through the text file line by line and ask the user 
 * for what he would like to search for.
 * 
 * If nothing is found, the program will tell you nothing is found,
 * and ask if you would like to run the program again. 
 *
 */

//importing scanner and arrayList.
import java.io.*;
import java.util.*;
public class beerProject {//start of class
	// creating ArrayList called beerList
	private static ArrayList<String> beerList;
	/**
	 * Main method 
	 * used to call methods and 
	 * insert data into method paramters.
	 */
	public static void main(String[] args) {//start of main
	

		//Scanner for user input
		Scanner keyboard = new Scanner(System.in);

		//text file stored in array
		beerList = readFileArrayList("beers.txt");
		   
		 //text file sent to the printArrayList method
		printArrayList(beerList);
		   
		//Sending the sperated by tabs array list
		search(beerList);
		  
		// flag value is true or false will enter the loop again
		while(true){ //start of while
			
		//Asking the user if he would like to play again
		System.out.println("");
		System.out.println("would you like to search again? select Y/N");

		//user input being stored in userInput String 
		String userInput=keyboard.nextLine();
		   
		//if to see if you would like to play again, if yes! the search method will be called again
		if(userInput.equalsIgnoreCase("y")){//start of if
		  search(beerList);
		         
		   }// if the user selects no then the program will exit 
		   else if(userInput.equalsIgnoreCase("n")){ 
		      System.out.println(""); 
		      System.out.println("The progam has ended");       
		      System.exit(0);
		   
		  }//end of else if 
		  
		  
		  
		 
		} // end while

		}//end main

		/**Method that is void to print out the List (does not return)
		 * 
		 */
		private static void printArrayList(ArrayList<String> theArrayList){//Start of method

		//for loop to print out the items in the array   
		for(int i = 0; i < theArrayList.size(); i++){//start of forloop
		   
		   //printing out the array that is seperated by tabs
		   System.out.println(theArrayList.get(i));
		   
		}//end of forloop

		}//end of printArrayList method
		
		/**
		 * ReadFile method will take the file and store The information into,
		 * an arrayList.
		 *The Array will then be returned to be used later
		 */
		private static ArrayList<String> readFileArrayList(String fileName){//start of method
		//Creating a new arrayList
		ArrayList<String>namelist=new ArrayList<String>();
		    
		try{//Start of try
		   
		//String array created
		String [] myline;
		   
		//start of open file. beers.txt stored in myFile
		File myFile = new File(fileName);
		//Scanner to inputfile into variable 
		Scanner inputFile = new Scanner(myFile);
		   
		   //Read file until there are no more lines left
		   while(inputFile.hasNext()){//Start of while loop
		   
		     //store the next line of the textfile in the string named line
		      String line = inputFile.nextLine();
		      //myline is an array that has text split by tabs
		         
		     //adding the myline array to the arraylist with split tabs
		     namelist.add(line);    
		     
		    }//end of while loop
		         
		    //close the file 
		    inputFile.close();
		    //returning the array with stored data
		    
		        }//end of try
		        
		     //exception thrown   
		    catch (IOException e){//start of catch
		    System.err.println("Error: " + e);
		}//end of catch

		//returning arrayList
		return namelist;


		}//end of method

		/**Method to search the array for certain strings*/
		private static String search(ArrayList <String> beerList){// Start of method

		//Scanner class
		Scanner keyboard = new Scanner(System.in);
		   
		//Asking for user input
		System.out.println("please enter a word to be searched in the text file ");
		   
		//Search for string
		String search = keyboard.nextLine();

		boolean flag = false;   
		//forloop to compare string to string in array
		for(String word : beerList){//start of for loop
		         
		   //if statement to compare user Input to String in array
		   if(word.toLowerCase().contains(search.toLowerCase())){//start of array
		            
		         //if found will display code
		         System.out.println("Found line:" + word);
		         flag= true;
		                  
		        }//end of if statement
		       
		     
		   }//end of forloop
		      if(!flag){//start of if
		      System.out.println("Nothing was found");
		      System.out.println("");
		   }//end of if

		//search returned   
		return  search;
		}//end of method
	}//end of class




